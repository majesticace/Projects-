/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Simple Math Game
  ******************************************************************************
  * @attention
  *
  * This game presents the user with a math question. It is played over the serial interface.
  * The user can reset the game with the on-board reset button of the NUCLEO board.
  * Baud Rate = 115200
  *
  * Copyright (c) 2023 STMicroelectronics.
  * Copyright (c) 2023 Dr. Billy Kihei, for CPE 2200
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <string.h>


/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart2;
DMA_HandleTypeDef hdma_usart2_rx;
DMA_HandleTypeDef hdma_usart2_tx;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
#define MAP_HEIGHT 10
#define MAP_WIDTH 10

static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_DMA_Init(void);
/* USER CODE BEGIN PFP */
void displayWelcome(void);
void handleGameState(void);
void handleGameInit(void);
void handleInGame(void);
void handleAskedQuestion(void);
void handleGameOver(void);
void updateMap(void);
void printMap(void);
void movePlayer(char direction);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

volatile uint8_t dataAvail = 0;
char rx_buff[1];
uint8_t Welcome[] = "Welcome to \r\n \
  █████╗░██╗░░░██╗██████╗░░██████╗███████╗██████╗░░█████╗░██████╗░███╗░░██╗\r\n \
 ██╔══██╗██║░░░██║██╔══██╗██╔════╝██╔════╝██╔══██╗██╔══██╗██╔══██╗████╗░██║\r\n \
 ██║░░╚═╝██║░░░██║██████╔╝╚█████╗░█████╗░░██████╦╝██║░░██║██████╔╝██╔██╗██║\r\n \
 ██║░░██╗██║░░░██║██╔══██╗░╚═══██╗██╔══╝░░██╔══██╗██║░░██║██╔══██╗██║╚████║\r\n \
 ╚█████╔╝╚██████╔╝██║░░██║██████╔╝███████╗██████╦╝╚█████╔╝██║░░██║██║░╚███║\r\n \
 ░╚════╝░░╚═════╝░╚═╝░░╚═╝╚═════╝░╚══════╝╚═════╝░░╚════╝░╚═╝░░╚═╝╚═╝░░╚══╝ \r\n"
		"Press P to continue or e to exit\r\n""";


uint8_t GoodbyeMsg[] = "𝒯𝒽𝒶𝓃𝓀 𝓎ℴ𝓊 𝒻ℴ𝓇 𝓅𝓁𝒶𝓎𝒾𝓃ℊ\r\n"; //Data to send
uint8_t WinMsg[] = "You win! \r\n"; //Data to send
uint8_t NotCorrectMsg[] = "Sorry...try again! \r\n"; //Data to send
uint8_t GameMsg[] = "What is 1+1? \r\n"; //Data to send
uint8_t Intro_1Msg[] = "In this game, you will navigate through maps, collect keys, and defeat bosses. \r\n";
uint8_t Intro_2Msg[] = "You will be able to collect keys to unlock doors and unlock chests. \r\n";
uint8_t Intro_3Msg[] = "Your goal is to collect all the keys and reach the end of the game.\r\n";
uint8_t Diff_CMsg[] = "You can either select the warrior (easier) or the wizard (harder) to be your class. You can press s or m respectively to choose your class \r\n";
uint8_t Mage[] = "You have selected the mage class with hard difficulty \r\n"; //Data to send
uint8_t Warrior[] = "You have selected the warrior class with easy difficulty \r\n"; //Data to send
uint8_t NotCorrectMsg2[] = "Sorry...try again! \r\n"; //Data to send
uint8_t GameMsg2[] = "What is 1+1? \r\n"; //Data to send
uint8_t Obj[] = "Hit M to see the map, with + being the player and = being objectives  \r\n ";
uint8_t InvalidMoveMsg[] = "Invalid move. Try again.";
uint8_t MovedToMsg[] = "Moved to (%d, %d).\n";
uint8_t CollectedAllKeysMsg[] = "Congratulations! You've collected all keys!\n";
uint8_t WonGameMsg[] = "Congratulations! You've won with a score of %d!\n";
uint8_t InvalidChoiceMsg[] = "Invalid choice. Please try again.\n";
uint8_t NoKeyFoundMsg[] = "No key found at this location.\n";
uint8_t FoundKeyMsg[] = "You found a key!\n";
uint8_t BossDefeatedMsg[] = "Boss defeated! You've earned a Token!\n";
uint8_t TokenDroppedMsg[] = "Token dropped at (%d, %d)\n";
uint8_t NoMoreBossesMsg[] = "No more bosses on this map.\n";
uint8_t CompletedAllMapsMsg[] = "Congratulations! You've completed all maps!\n";
uint8_t CorrectAnswerMsg[] = "Correct!\n";
char map[10][10];
typedef enum {
    CLASS_NONE,
    CLASS_WARRIOR,
    CLASS_WIZARD
} PlayerClass;

PlayerClass playerClass = CLASS_NONE;

typedef enum {
    STATE_INIT,
    STATE_TITLE,
	STATE_BossE,
	STATE_WARRIOR,
	STATE_MAGE,
	STATE_BHE1,
	STATE_BHE2,
	STATE_BHE3,
	STATE_BEE1,
	STATE_BEE3,
	STATE_BEE2,
	STATE_NEWMAP,
	STATE_NEWMAP2,
    STATE_CLASS_DIFFICULTY,
    STATE_HARD_GAME,
	STATE_EASY_GAME,
    STATE_GAME_OVER
} GameState;


typedef struct {
    int x;
    int y;
} PlayerPosition;

PlayerPosition playerPos = {2, 2}; // Initial position of the player
PlayerPosition bossPos = {5, 7};
;


void updateMap(void)
{
    // Clear the previous player position
    map[playerPos.y][playerPos.x] = '.';

    // Update the player's position on the map
    map[playerPos.y][playerPos.x] = '+';

    // Uncomment the line below if you want to clear the screen before printing the updated map
    HAL_UART_Transmit(&huart2, "\033[2J", 4, HAL_MAX_DELAY);

}
// Add a global flag to indicate whether UART transmission is complete
volatile uint8_t uartTransmissionComplete = 0;

// Callback function for UART transmission completion
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
    uartTransmissionComplete = 1;
}
void movePlayer(char direction)
{
    // Clear the previous player position
    map[playerPos.y][playerPos.x] = '.';

    switch (direction)
    {
    case 'n':
        playerPos.y--;
        break;
    case 's':
        playerPos.y++;
        break;
    case 'e':
        playerPos.x++;
        break;
    case 'w':
        playerPos.x--;
        break;
    default:
        // Handle invalid direction
        break;
    }
    updateMap(); // Update the map after each movement
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_DMA_Init();
  /* USER CODE BEGIN 2 */
  HAL_UART_Receive_IT(&huart2, rx_buff, 1);
  /* USER CODE END 2 */

  /* Game engine runs in infinite loop until finished. */
  /* Game engine BEGIN WHILE */
  uint8_t init = 0;
  uint8_t inGame = 0;
  uint8_t pIR = 0;
  uint8_t pWM = 0;
  uint8_t pIM = 0;
  uint8_t askedGameQuestion = 0;
  uint8_t questionCounter = 0;
  uint8_t sE = 0;
  uint8_t seenmap = 0;
  GameState gameState = STATE_INIT;
  static uint8_t warriorMessageSent = 0;
  static uint8_t mageMessageSent = 0;
  int initialMapPrinted = 0;
  const char map[MAP_HEIGHT][MAP_WIDTH + 1] = {
      "##########",
      "#........#",
      "#.+....=.#",
      "#........#",
      "#--------#",
      "#........#",
      "#.*......#",
      "#.=......#",
      "#........#",
      "##########"
  };
  const char map2[MAP_HEIGHT][MAP_WIDTH + 1] = {
       "##########",
       "#........#",
       "#......=.#",
       "#........#",
       "#--------#",
       "#.+......#",
       "#.*......#",
       "#.=......#",
       "#........#",
       "##########"
   };
  //Function to print the map
  void printMap(void)
  {
      for (int i = 0; i < MAP_HEIGHT; i++)
      {
          HAL_UART_Transmit(&huart2, map[i], MAP_WIDTH, HAL_MAX_DELAY);
          HAL_UART_Transmit(&huart2, "\r\n", 2, HAL_MAX_DELAY);
      }
  }
  void printMap2(void)
  {
      for (int i = 0; i < MAP_HEIGHT; i++)
      {
          HAL_UART_Transmit(&huart2, map2[i], MAP_WIDTH, HAL_MAX_DELAY);
          HAL_UART_Transmit(&huart2, "\r\n", 2, HAL_MAX_DELAY);
      }
  }
  HAL_UART_Receive_IT(&huart2, rx_buff, 1); // Move this here

  while (1)
  {
      static uint8_t loaded = 0;  // Variable to track whether initialization is done

      switch (gameState)
      {
      case STATE_INIT:
          // Initialization code
          if (!loaded)
          {
              HAL_UART_Transmit_IT(&huart2, Welcome, sizeof(Welcome));
              while (!uartTransmissionComplete);  // Wait for completion
              uartTransmissionComplete = 0;  // Reset the flag
              loaded = 1;  // Set loaded to 1 to indicate initialization is done
          }

          if (dataAvail)
          {
              switch (rx_buff[0])
              {
              case 'p':
                  gameState = STATE_CLASS_DIFFICULTY;
                  dataAvail = 0;
                  break;
              case 'e':
                  gameState = STATE_GAME_OVER;
                  dataAvail = 0;
                  break;
              // Add other cases for additional transitions
              }
          }
          break;

      case STATE_CLASS_DIFFICULTY:
          // Handle class/difficulty selection
          if (askedGameQuestion == 0)
          {
              HAL_UART_Transmit_IT(&huart2, Diff_CMsg, sizeof(Diff_CMsg));
              while (!uartTransmissionComplete);  // Wait for completion
              uartTransmissionComplete = 0;  // Reset the flag
              askedGameQuestion = 1;
          }
          else
          {
              if (dataAvail)
              {
                  switch (rx_buff[0])
                  {
                  case 'm':
                      playerClass = CLASS_WIZARD;
                      HAL_UART_Transmit_IT(&huart2, Mage, sizeof(Mage));
                      gameState = STATE_MAGE;
                      dataAvail = 0; // Reset dataAvail after handling valid input
                      break;

                  case 's':
                      playerClass = CLASS_WARRIOR;
                      HAL_UART_Transmit_IT(&huart2, Warrior, sizeof(Warrior));
                      gameState = STATE_WARRIOR;
                      dataAvail = 0; // Reset dataAvail after handling valid input
                      break;

                  default:
                      // Handle invalid input
                      HAL_UART_Transmit_IT(&huart2, InvalidChoiceMsg, sizeof(InvalidChoiceMsg));
                      HAL_UART_Receive_IT(&huart2, rx_buff, 1); // Wait for the next character
                      dataAvail = 0; // Reset dataAvail after handling invalid input
                      break; // Exit the switch without further processing to avoid repeated messages
                  }
              }
          }
          break;
      case STATE_WARRIOR:
          // Handle warrior-specific actions
          if (!warriorMessageSent)
          {
              HAL_UART_Transmit_IT(&huart2, "You have selected the warrior class with easy difficulty \r\n", sizeof("You have selected the warrior class with easy difficulty \r\n"));
              warriorMessageSent = 1;
          }
          gameState = STATE_EASY_GAME;
          // Example: Display messages, perform actions
          // Transition to other states based on game logic
          // Example transition: gameState = STATE_GAMEPLAY;
          break;

      case STATE_MAGE:
          // Handle mage-specific actions
          if (!mageMessageSent)
          {
              HAL_UART_Transmit_IT(&huart2, "You have selected the mage class with hard difficulty \r\n", sizeof("You have selected the mage class with hard difficulty \r\n"));
              mageMessageSent = 1;
          }
          gameState = STATE_HARD_GAME;
          break;


      case STATE_EASY_GAME:
    	  if (!seenmap)
    	      	            {
    	      	                HAL_UART_Transmit_IT(&huart2, Obj , sizeof(Obj));
    	      	                seenmap = 1;
    	      	            }

    	            if (dataAvail)
    	            {
    	                switch (rx_buff[0])
    	                {
    	                case 'm':
    	                    // Redraw the map with the updated player position
    	                    printMap();
    	                    // Reset dataAvail after handling input
    	                    dataAvail = 0;
    	                    // Add a delay to allow time for the map to be transmitted
    	                    HAL_Delay(100);
    	                    // Ask the user where they would like to go
    	                    HAL_UART_Transmit_IT(&huart2, "Where would you like to go?\r\n", sizeof("Where would you like to go?\r\n"));
    	                    break;

    	                case 'e':
    	                    // Move east
    	                    HAL_UART_Transmit_IT(&huart2, "You have moved east\r\n", sizeof("You have moved east\r\n"));
    	                    while (!uartTransmissionComplete);  // Wait for completion
    	                    uartTransmissionComplete = 0;  // Reset the flag
    	                    gameState = STATE_BEE1; // Transition to the new state
    	                    dataAvail = 0; // Reset dataAvail after handling input
    	                    break;

    	                default:
    	                    // Handle invalid input
    	                    HAL_UART_Transmit_IT(&huart2, InvalidMoveMsg, sizeof(InvalidMoveMsg));
    	                    while (!uartTransmissionComplete);  // Wait for completion
    	                    uartTransmissionComplete = 0;  // Reset the flag
    	                    dataAvail = 0; // Reset dataAvail after handling invalid input
    	                    break;
    	                }
    	            }
    	            break;

      case STATE_HARD_GAME:
    	  if (!seenmap)
    	            {

    	                HAL_UART_Transmit_IT(&huart2, Obj , sizeof(Obj));
    	                seenmap = 1;
    	            }

          if (dataAvail)
          {
              switch (rx_buff[0])
              {
              case 'm':
                  // Redraw the map with the updated player position
                  printMap();
                  // Reset dataAvail after handling input
                  dataAvail = 0;
                  // Add a delay to allow time for the map to be transmitted
                  HAL_Delay(100);
                  // Ask the user where they would like to go
                  HAL_UART_Transmit_IT(&huart2, "Where would you like to go?\r\n", sizeof("Where would you like to go?\r\n"));
                  break;

              case 'e':
                  // Move east
                  HAL_UART_Transmit_IT(&huart2, "You have moved east\r\n", sizeof("You have moved east\r\n"));
                  while (!uartTransmissionComplete);  // Wait for completion
                  uartTransmissionComplete = 0;  // Reset the flag
                  gameState = STATE_BHE1; // Transition to the new state
                  dataAvail = 0; // Reset dataAvail after handling input
                  break;

              default:
                  // Handle invalid input
                  HAL_UART_Transmit_IT(&huart2, InvalidMoveMsg, sizeof(InvalidMoveMsg));
                  while (!uartTransmissionComplete);  // Wait for completion
                  uartTransmissionComplete = 0;  // Reset the flag
                  dataAvail = 0; // Reset dataAvail after handling invalid input
                  break;
              }
          }
          break;
      case STATE_BHE1:
          // Handle actions specific to STATE_BHE1
    	  questionCounter = 0;
          if (!sE)
          {
              HAL_UART_Transmit_IT(&huart2, "You encounter a spirit and it prevents you from moving until you answer both its questions correctly.\r \n", sizeof("You encounter a spirit and it prevents you from moving until you answer both its questions correctly.\r\n"));
              while (!uartTransmissionComplete);  // Wait for completion
              uartTransmissionComplete = 0;  // Reset the flag
              HAL_UART_Transmit_IT(&huart2, "What is the 2^3? \r\n", sizeof("What is the 2^3? \r\n"));
              while (!uartTransmissionComplete);  // Wait for completion
              uartTransmissionComplete = 0;  // Reset the flag
              sE = 1; // Set the flag to true
          }
          else
          {
              if (dataAvail)
              {
                  switch (questionCounter)
                  {
                  case 0:
                      // Check the answer to the first question
                      if (rx_buff[0] == '8')
                      {
                          // Correct answer, move on to the next question
                          questionCounter++;
                          HAL_UART_Transmit_IT(&huart2, "Correct!\r\n", sizeof("Correct!\r\n"));
                          while (!uartTransmissionComplete);  // Wait for completion
                          uartTransmissionComplete = 0;  // Reset the flag
                          gameState = STATE_NEWMAP;
                      }
                      else
                      {
                          // Incorrect answer
                          HAL_UART_Transmit_IT(&huart2, "Nice try!\n", sizeof("Nice try!\n"));
                          gameState = STATE_GAME_OVER; // Transition to the game over state
                      }
                      break;
                  default:
                      break;
                  }

                  dataAvail = 0; // Reset dataAvail after handling input
              }
          }
          break;
      case STATE_BEE1:
               // Handle actions specific to STATE_BHE1
         	  questionCounter = 0;
               if (!sE)
               {
                   HAL_UART_Transmit_IT(&huart2, "You encounter a spirit and it prevents you from moving until you answer both its questions correctly.\r \n", sizeof("You encounter a spirit and it prevents you from moving until you answer both its questions correctly.\r\n"));
                   while (!uartTransmissionComplete);  // Wait for completion
                   uartTransmissionComplete = 0;  // Reset the flag
                   HAL_UART_Transmit_IT(&huart2, "What is the 2+3? \r\n", sizeof("What is the 2+3? \r\n"));
                   while (!uartTransmissionComplete);  // Wait for completion
                   uartTransmissionComplete = 0;  // Reset the flag
                   sE = 1; // Set the flag to true
               }
               else
               {
                   if (dataAvail)
                   {
                       switch (questionCounter)
                       {
                       case 0:
                           // Check the answer to the first question
                           if (rx_buff[0] == '5')
                           {
                               // Correct answer, move on to the next question
                               questionCounter++;
                               HAL_UART_Transmit_IT(&huart2, "Correct!\r\n", sizeof("Correct!\r\n"));
                               while (!uartTransmissionComplete);  // Wait for completion
                               uartTransmissionComplete = 0;  // Reset the flag
                               gameState = STATE_NEWMAP2;
                           }
                           else
                           {
                               // Incorrect answer
                               HAL_UART_Transmit_IT(&huart2, "Nice try!\n", sizeof("Nice try!\n"));
                               gameState = STATE_GAME_OVER; // Transition to the game over state
                           }
                           break;
                       default:
                           break;
                       }

                       dataAvail = 0; // Reset dataAvail after handling input
                   }
               }
               break;
      case STATE_NEWMAP:
                            // Print the welcome message only once when entering the state
                            if (!pWM) {
                                HAL_UART_Transmit_IT(&huart2, "Welcome to the other side of the map, where would you like to go?\r\n", sizeof("Welcome to the other side of the map, where would you like to go?\r\n"));
                                pWM = 1;
                            }

                            // Check for user input
                            if (dataAvail) {
                                // Assuming rx_buff[0] contains the user input
                                if (rx_buff[0] == 's' || rx_buff[0] == 'S') {
                                    // User chose to go south, transition to BHE2 state
                                    gameState = STATE_BHE2;
                                    // Additional logic for transitioning to BHE2 if needed
                                } else if (rx_buff[0] == 'm' || rx_buff[0] == 'M') {
                                    // User chose to view the second map, call printMap2()
                                    printMap2();
                                    // Additional logic for handling map view if needed
                                } else {
                                    // Handle invalid input if needed
                                    HAL_UART_Transmit_IT(&huart2, "Invalid input. Please enter 's' to go south or 'm' to view the map.\n", sizeof("Invalid input. Please enter 's' to go south or 'm' to view the map.\n"));
                                    // Additional logic for handling invalid input if needed
                                }

                                dataAvail = 0; // Reset dataAvail after handling input
                            }
                            break;
      case STATE_NEWMAP2:
                      // Print the welcome message only once when entering the state
                      if (!pWM) {
                          HAL_UART_Transmit_IT(&huart2, "Welcome to the other side of the map, where would you like to go?\r\n", sizeof("Welcome to the other side of the map, where would you like to go?\r\n"));
                          pWM = 1;
                      }

                      // Check for user input
                      if (dataAvail) {
                          // Assuming rx_buff[0] contains the user input
                          if (rx_buff[0] == 's' || rx_buff[0] == 'S') {
                              // User chose to go south, transition to BHE2 state
                              gameState = STATE_BEE2;
                              // Additional logic for transitioning to BHE2 if needed
                          } else if (rx_buff[0] == 'm' || rx_buff[0] == 'M') {
                              // User chose to view the second map, call printMap2()
                              printMap2();
                              // Additional logic for handling map view if needed
                          } else {
                              // Handle invalid input if needed
                              HAL_UART_Transmit_IT(&huart2, "Invalid input. Please enter 's' to go south or 'm' to view the map.\n", sizeof("Invalid input. Please enter 's' to go south or 'm' to view the map.\n"));
                              // Additional logic for handling invalid input if needed
                          }

                          dataAvail = 0; // Reset dataAvail after handling input
                      }
                      break;
      case STATE_BHE2:
          // Print the initial message only once when entering the state
          if (!pIM) {
              HAL_UART_Transmit_IT(&huart2, "In order to proceed, you must answer my question. Solve for x: 2x + 5 = 15\r\n", sizeof("In order to proceed, you must answer my question. Solve for x: 2x + 5 = 15\r\n"));
              pIM = 1;
          }

          // Check for user input
          if (dataAvail) {
              // Assuming rx_buff[0] contains the user input
              if (rx_buff[0] == '5') {
                  // User answered correctly, proceed to the next question
                  pIM = 0;  // Reset the flag to print the initial message next time
                  HAL_UART_Transmit_IT(&huart2, "Correct! You now move on to the final trail\r\n", sizeof("Correct! You now move on to the final trail\r\n"));
                  gameState = STATE_BHE3;
                  // Additional logic for transitioning to BHE3 if needed
              } else {
                  // Incorrect answer
                  HAL_UART_Transmit_IT(&huart2, "Nice try! You can't proceed until you answer correctly.\n", sizeof("Nice try! You can't proceed until you answer correctly.\n"));
                  // Additional logic for handling incorrect answer if needed
              }

              dataAvail = 0; // Reset dataAvail after handling input
          }
          break;
      case STATE_BEE2:
                // Print the initial message only once when entering the state
                if (!pIM) {
                    HAL_UART_Transmit_IT(&huart2, "In order to proceed, you must answer my question. Solve for  x = 10 - 2\r\n", sizeof("In order to proceed, you must answer my question. Solve for x = 10 - 2\r\n"));
                    pIM = 1;
                }

                // Check for user input
                if (dataAvail) {
                    // Assuming rx_buff[0] contains the user input
                    if (rx_buff[0] == '8') {
                        // User answered correctly, proceed to the next question
                        pIM = 0;  // Reset the flag to print the initial message next time
                        HAL_UART_Transmit_IT(&huart2, "Correct! You now move on to the final trail\r\n", sizeof("Correct! You now move on to the final trail\r\n"));
                        gameState = STATE_BEE3;
                        // Additional logic for transitioning to BHE3 if needed
                    } else {
                        // Incorrect answer
                        HAL_UART_Transmit_IT(&huart2, "Nice try! You can't proceed until you answer correctly.\n", sizeof("Nice try! You can't proceed until you answer correctly.\n"));
                        // Additional logic for handling incorrect answer if needed
                    }

                    dataAvail = 0; // Reset dataAvail after handling input
                }
                break;
      case STATE_BHE3:
          // Print the initial message only once when entering the state
          if (!pIR) {
             HAL_UART_Transmit_IT(&huart2, "The final question is:\r\n "
            		  "If a shirt costs $20 and is discounted by 25%, what is the saving?\r\n",
					  sizeof("The final question is:\r\n "
		            		  "If a shirt costs $20 and is discounted by 25%, what is the saving?\r\n"));
              pIR = 1;
          }

          // Check for user input
          if (dataAvail) {
              // Assuming rx_buff[0] contains the user input
              if (rx_buff[0] == '5') {
                  // User answered correctly, congratulate them on beating the game
                  pIR = 0;  // Reset the flag to print the initial message next time
                  HAL_UART_Transmit_IT(&huart2, "Congratulations! You have beaten the game.\n", sizeof("Congratulations! You have beaten the game.\n"));
                  gameState = STATE_GAME_OVER;  // or any other appropriate state
                  // Additional logic for transitioning to the game over state if needed
              } else {
                  // Incorrect answer
                  HAL_UART_Transmit_IT(&huart2, "Nice try! That's not the correct answer. Keep trying!\n", sizeof("Nice try! That's not the correct answer. Keep trying!\n"));
                  // Additional logic for handling incorrect answer if needed
              }

              dataAvail = 0; // Reset dataAvail after handling input
          }
          break;
      case STATE_BEE3:
                // Print the initial message only once when entering the state
                if (!pIR) {
                   HAL_UART_Transmit_IT(&huart2, "The final question is:\r\n "
                  		  "what is the 3+3\r\n",
      					  sizeof("The final question is:\r\n "
      							"what is the 3+3+3 \r\n"));
                    pIR = 1;
                }

                // Check for user input
                if (dataAvail) {
                    // Assuming rx_buff[0] contains the user input
                    if (rx_buff[0] == '9') {
                        // User answered correctly, congratulate them on beating the game
                        pIR = 0;  // Reset the flag to print the initial message next time
                        HAL_UART_Transmit_IT(&huart2, "Congratulations! You have beaten the game.\n", sizeof("Congratulations! You have beaten the game.\n"));
                        gameState = STATE_GAME_OVER;  // or any other appropriate state
                        // Additional logic for transitioning to the game over state if needed
                    } else {
                        // Incorrect answer
                        HAL_UART_Transmit_IT(&huart2, "Nice try! That's not the correct answer. Keep trying!\n", sizeof("Nice try! That's not the correct answer. Keep trying!\n"));
                        // Additional logic for handling incorrect answer if needed
                    }

                    dataAvail = 0; // Reset dataAvail after handling input
                }
                break;
      case STATE_GAME_OVER:
          // Handle the game over state
          if (playerClass == CLASS_WIZARD)
          {
              HAL_UART_Transmit(&huart2, "Wizard, ", 8, 10);
          }
          else if (playerClass == CLASS_WARRIOR)
          {
              HAL_UART_Transmit(&huart2, "Warrior, ", 9, 10);
          }
          HAL_UART_Transmit(&huart2, GoodbyeMsg, sizeof(GoodbyeMsg), 10);
          while (1)
          {
              // Add any code you want to execute inside the infinite loop
          }
          break;
      }
      HAL_UART_Receive_IT(&huart2, rx_buff, 1);
  }


     }


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 10;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel6_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel6_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel6_IRQn);
  /* DMA1_Channel7_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel7_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel7_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LD2_Pin */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
/* If UART2 has received a byte from the user terminal this function
 * will be called.
 * dataAvail is used to indicate that the rx_buff has received new data and can be checked.
 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    HAL_UART_Receive_IT(&huart2, rx_buff, 1);
    dataAvail = 1;
}




/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

